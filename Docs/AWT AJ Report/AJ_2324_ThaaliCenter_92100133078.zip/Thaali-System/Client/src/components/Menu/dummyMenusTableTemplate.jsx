// import React from 'react';
import React, { useState, useEffect, useRef } from "react";
import { DataTable } from "primereact/datatable";
import { InputText } from "primereact/inputtext";
import { Column } from "primereact/column";
// import { ProductService } from './service/ProductService';
import { Rating } from "primereact/rating";
import { Button } from "primereact/button";
import { Tag } from "primereact/tag";
import { Toast } from "primereact/toast";

function Menus() {
    // Sample data for demonstration
    const sampleData = [
        {
            id: 1000,
            name: "Sample Menu 1",
            image: "sample_image_1.jpg",
            price: 9.99,
            category: "Category 1",
            rating: 4,
            inventoryStatus: "INSTOCK",
            orders: [
                {
                    id: 1,
                    customer: "John Doe",
                    date: "2024-04-10",
                    amount: 20.5,
                    status: "DELIVERED",
                },
                {
                    id: 2,
                    customer: "Jane Doe",
                    date: "2024-04-09",
                    amount: 15.75,
                    status: "PENDING",
                },
            ],
        },
        {
            id: 1001,
            name: "Sample Menu 2",
            image: "sample_image_2.jpg",
            price: 14.99,
            category: "Category 2",
            rating: 3,
            inventoryStatus: "LOWSTOCK",
            orders: [
                {
                    id: 3,
                    customer: "Alice Smith",
                    date: "2024-04-08",
                    amount: 30.25,
                    status: "CANCELLED",
                },
            ],
        },
    ];
    const [selectedRows, setSelectedRows] = useState([]);
    const [products, setProducts] = useState(sampleData);
    const [expandedRows, setExpandedRows] = useState(null);
    const toast = useRef(null);
    const [globalFilter, setGlobalFilter] = useState("");
    useEffect(() => {
        // ProductService.getProductsWithOrdersSmall().then((data) => setProducts(data));
        // Commented out because ProductService is not defined in the provided code
        setProducts(sampleData);
    }, []); // eslint-disable-line react-hooks/exhaustive-deps

    const onRowExpand = (event) => {
        // toast.current.show({ severity: 'info', summary: 'Product Expanded', detail: event.data.name, life: 3000 });
    };

    const onRowCollapse = (event) => {
        // toast.current.show({ severity: 'success', summary: 'Product Collapsed', detail: event.data.name, life: 3000 });
    };

    const expandAll = () => {
        let _expandedRows = {};

        products.forEach((p) => (_expandedRows[`${p.id}`] = true));

        setExpandedRows(_expandedRows);
    };

    const collapseAll = () => {
        setExpandedRows(null);
    };

    const formatCurrency = (value) => {
        return value.toLocaleString("en-US", {
            style: "currency",
            currency: "USD",
        });
    };

    const amountBodyTemplate = (rowData) => {
        return formatCurrency(rowData.amount);
    };

    const statusOrderBodyTemplate = (rowData) => {
        return (
            <Tag
                value={rowData.status.toLowerCase()}
                severity={getOrderSeverity(rowData)}
            ></Tag>
        );
    };

    const searchBodyTemplate = () => {
        return <Button icon="pi pi-search" />;
    };

    const imageBodyTemplate = (rowData) => {
        return (
            <img
                src={`https://primefaces.org/cdn/primereact/images/product/${rowData.image}`}
                alt={rowData.image}
                width="64px"
                className="shadow-4"
            />
        );
    };

    const priceBodyTemplate = (rowData) => {
        return formatCurrency(rowData.price);
    };

    const ratingBodyTemplate = (rowData) => {
        return <Rating value={rowData.rating} readOnly cancel={false} />;
    };

    const statusBodyTemplate = (rowData) => {
        return (
            <Tag
                value={rowData.inventoryStatus}
                severity={getProductSeverity(rowData)}
            ></Tag>
        );
    };

    const getProductSeverity = (product) => {
        switch (product.inventoryStatus) {
            case "INSTOCK":
                return "success";

            case "LOWSTOCK":
                return "warning";

            case "OUTOFSTOCK":
                return "danger";

            default:
                return null;
        }
    };

    const getOrderSeverity = (order) => {
        switch (order.status) {
            case "DELIVERED":
                return "success";

            case "CANCELLED":
                return "danger";

            case "PENDING":
                return "warning";

            case "RETURNED":
                return "info";

            default:
                return null;
        }
    };

    const allowExpansion = (rowData) => {
        return rowData.orders.length > 0;
    };

    const rowExpansionTemplate = (data) => {
        return (
            <div className="p-3">
                {/* <h5>Orders for {data.name}</h5> */}
                <DataTable
                    value={data.orders}
                    paginator
                    rows={10}
                    rowsPerPageOptions={[10, 35]}
                    paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
                    currentPageReportTemplate="Showing {first} to {last} of {totalRecords} entries"
                    globalFilter={globalFilter}
                    dataKey="id"
                    // header={header}
                    selectionMode="multiple"
                    selection={selectedRows}
                    onSelectionChange={(e) => setSelectedRows(e.value)}
                    style={{ fontSize: "1em" }}
                    tableStyle={{
                        minWidth: "60rem",
                    }}
                >
                    <Column field="id" header="Id" sortable></Column>
                    <Column
                        field="customer"
                        header="Customer"
                        sortable
                    ></Column>
                    <Column field="date" header="Date" sortable></Column>
                    <Column
                        field="amount"
                        header="Amount"
                        body={amountBodyTemplate}
                        sortable
                    ></Column>
                    <Column
                        field="status"
                        header="Status"
                        body={statusOrderBodyTemplate}
                        sortable
                    ></Column>
                    <Column
                        headerStyle={{ width: "4rem" }}
                        body={searchBodyTemplate}
                    ></Column>
                </DataTable>
            </div>
        );
    };

    const header = (
        <>
            <div className="table-header d-flex justify-content-between">
                <span className="p-input-icon-left">
                    <i className="pi pi-search" />
                    <InputText
                        type="search"
                        onInput={(e) => setGlobalFilter(e.target.value)}
                        placeholder="Search User"
                    />
                </span>
                <div className="d-flex gap-2">
                    <Button
                        icon="pi pi-plus"
                        label="Expand All"
                        onClick={expandAll}
                        text
                    />
                    <Button
                        icon="pi pi-minus"
                        label="Collapse All"
                        onClick={collapseAll}
                        text
                    />
                </div>
            </div>
        </>
    );

    return (
        <>
            <div className="page-wrapper">
                <div className="page-header d-print-none">
                    <div className="container-xl">
                        <div className="row g-2 align-items-center">
                            <div className="col">
                                <div className="page-pretitle">Overview</div>
                                <h2 className="page-title">Menus</h2>
                            </div>

                            <div className="col-auto ms-auto d-print-none">
                                <div className="btn-list">
                                    <a
                                        // href="#"
                                        className="btn btn-primary d-none d-sm-inline-block"
                                        // data-bs-toggle="modal"
                                        // data-bs-target="#modal-report"
                                        href="/CreateMenu"
                                    >
                                        <svg
                                            xmlns="http://www.w3.org/2000/svg"
                                            className="icon"
                                            width="24"
                                            height="24"
                                            viewBox="0 0 24 24"
                                            strokeWidth="2"
                                            stroke="currentColor"
                                            fill="none"
                                            strokeLinecap="round"
                                            strokeLinejoin="round"
                                        >
                                            <path
                                                stroke="none"
                                                d="M0 0h24v24H0z"
                                                fill="none"
                                            />
                                            <path d="M12 5l0 14" />
                                            <path d="M5 12l14 0" />
                                        </svg>
                                        Create new Menu
                                    </a>
                                    {/* <a
                                        href="#"
                                        className="btn btn-primary d-sm-none btn-icon"
                                        data-bs-toggle="modal"
                                        data-bs-target="#modal-report"
                                        aria-label="Create new report"
                                    >
                                        <svg
                                            xmlns="http://www.w3.org/2000/svg"
                                            className="icon"
                                            width="24"
                                            height="24"
                                            viewBox="0 0 24 24"
                                            strokeWidth="2"
                                            stroke="currentColor"
                                            fill="none"
                                            strokeLinecap="round"
                                            strokeLinejoin="round"
                                        >
                                            <path
                                                stroke="none"
                                                d="M0 0h24v24H0z"
                                                fill="none"
                                            />
                                            <path d="M12 5l0 14" />
                                            <path d="M5 12l14 0" />
                                        </svg>
                                    </a> */}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="col-12">
                    <Toast ref={toast} />
                    <div className="page-body">
                        <div className="container-xl">
                            <div className="row row-deck row-cards">
                                <div className="container-fluid">
                                    <div className="row">
                                        <div className="card">
                                            <div className="card-body">
                                                {/* <Toast ref={toast} /> */}
                                                <DataTable
                                                    value={products}
                                                    expandedRows={expandedRows}
                                                    onRowToggle={(e) =>
                                                        setExpandedRows(e.data)
                                                    }
                                                    onRowExpand={onRowExpand}
                                                    onRowCollapse={
                                                        onRowCollapse
                                                    }
                                                    rowExpansionTemplate={
                                                        rowExpansionTemplate
                                                    }
                                                    paginator
                                                    rows={10}
                                                    rowsPerPageOptions={[
                                                        5, 10, 20, 40, 100,
                                                    ]}
                                                    paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
                                                    currentPageReportTemplate="Showing {first} to {last} of {totalRecords} entries"
                                                    globalFilter={globalFilter}
                                                    dataKey="id"
                                                    header={header}
                                                    selectionMode="multiple"
                                                    selection={selectedRows}
                                                    onSelectionChange={(e) =>
                                                        setSelectedRows(e.value)
                                                    }
                                                    style={{ fontSize: "1em" }}
                                                    tableStyle={{
                                                        minWidth: "60rem",
                                                    }}
                                                >
                                                    <Column
                                                        expander={
                                                            allowExpansion
                                                        }
                                                        style={{
                                                            width: "5rem",
                                                        }}
                                                    />
                                                    <Column
                                                        field="name"
                                                        header="Name"
                                                        sortable
                                                    />
                                                    <Column
                                                        header="Image"
                                                        body={imageBodyTemplate}
                                                    />
                                                    <Column
                                                        field="price"
                                                        header="Price"
                                                        sortable
                                                        body={priceBodyTemplate}
                                                    />
                                                    <Column
                                                        field="category"
                                                        header="Category"
                                                        sortable
                                                    />
                                                    <Column
                                                        field="rating"
                                                        header="Reviews"
                                                        sortable
                                                        body={
                                                            ratingBodyTemplate
                                                        }
                                                    />
                                                    <Column
                                                        field="inventoryStatus"
                                                        header="Status"
                                                        sortable
                                                        body={
                                                            statusBodyTemplate
                                                        }
                                                    />
                                                </DataTable>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div
                className="modal modal-blur fade"
                id="modal-small"
                tabIndex="-1"
                role="dialog"
                aria-hidden="true"
            >
                <div
                    className="modal-dialog modal-sm modal-dialog-centered"
                    role="document"
                >
                    <div className="modal-content">
                        <div className="modal-body">
                            <div className="modal-title">Are you sure?</div>
                            <div>If you proceed, the Menu will be deleted.</div>
                        </div>
                        <div className="modal-footer">
                            <button
                                type="button"
                                className="btn btn-link link-secondary me-auto"
                                data-bs-dismiss="modal"
                            >
                                Cancel
                            </button>
                            <button type="button" className="btn btn-danger">
                                {/* onClick={deleteMenu} */}
                                Yes, delete Menu
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
export default Menus;
