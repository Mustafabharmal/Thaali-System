package com.example.thaalisystemspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThaaliSystemSpringApplicationTests {

    @Test
    void contextLoads() {
    }

}
